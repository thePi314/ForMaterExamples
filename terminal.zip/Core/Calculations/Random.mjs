export function irandom_range(min, max) {
    return Math.floor(Math.random() * max) + min;
}