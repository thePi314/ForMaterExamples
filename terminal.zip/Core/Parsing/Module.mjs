export { default as parser_template } from './Template.mjs' ;
export { default as parser_normal } from './Normal.mjs' ;