import * as Core from '../Core/Module.mjs';

export default class Main extends Core.Object {
    constructor(type , x = 0 , y = 0 , width = window.innerWidth , height = window.innerHeight , innerHTML = '' , attributes = {} ) {
        super(type);

        this.x = x ; 
        this.y = y ;
        this.width = (width == 'max')?window.innerWidth:width ;
        this.height = (height == 'max')?window.innerHeight:height ;

        this.innerHTML = innerHTML ;

        for( let key in attributes ){
            this.attachAttribute( new Core.Attribute(key,attributes[key]) ) ;
        }
    }
}
