import * as Core from '../Core/Module.mjs';
import { irandom_range } from '../Core/Calculations/Random.mjs';

export default class TextBox extends Core.Object{
    constructor(type, text = '' ,  x = 0 , y = 0 , size = 16 , color = 'black'){
        super(type , 'textbox'+irandom_range(100000000,999999999) ) ;

        this.x = x ;
        this.y = y ;
        this.size = size ;
        this.color = color ;

        for( let ind_text = 0 ; ind_text < text.length ; ind_text++ ){
            this.innerHTML += (text[ind_text] != '\n')?text[ind_text]:"</br>" ;
        }

        this.width = 'max-content' ;
        this.height = 'max-content' ;

        this.attachAttribute( new Core.Attribute( 'color' , this.color ) );
        this.attachAttribute( new Core.Attribute( 'font-size' , this.size+"px" ) );
    
        this.animation_interval = null ;
    }

    getElementWidth(){
        if( document.getElementById(this.id) != null )
            return (document.getElementById(this.id).offsetWidth);
    
        return null ;
    }

    getElementHeight(){
        if( (document.getElementById(this.id) != null ) )
            return (document.getElementById(this.id).offsetHeight);

        return null ;
    }

}