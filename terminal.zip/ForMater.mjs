/* Modules */
import * as Core from './Core/Module.mjs';

/* Objects */
import * as Objects from './Objects/Modules.mjs';

var init_width = 0;
var init_height = 0;
var width = 0;
var height = 0;

var main_window = null;

var cursor = new Objects.Main('span', 12, 8, 1, 0, '', { 'background-color': 'darkgreen' });

var main_object = new Objects.Main('div', 0, 0, 'max', 'max', '', { 'background-color': 'black' });
var text_object = new Objects.TextBox('div', "root@user: ~$ ", 8, 8, 18, 'darkgreen');
let command_length = text_object.innerHTML.length;


var past_text = [];

window.onresize = async function () {
    width = window.innerWidth;
    height = window.innerHeight;
    applyStyle(main_object);
}

/* Constructor */
window.addEventListener('load', (event) => {
    init_width = width = window.innerWidth;
    init_height = height = window.innerHeight;

    main_window = document.getElementById('application');
    main_window.innerHTML = Core.parser_normal([main_object, text_object], init_width, init_height, init_width, init_height);

    cursor.x += text_object.getElementWidth();
    cursor.height = text_object.getElementHeight();

    let insert_at = 0;

    //content refresh 
    let frame_interval = setInterval(function () {
        let print_array = [main_object];

        for (let ind = 0; ind < past_text.length; ind++)
            print_array.push(past_text[ind]);

        print_array.push(text_object);

        cursor.width = (cursor.width == 2) ? 0 : 2;
        print_array.push(cursor);

        main_window.innerHTML = Core.parser_normal(print_array, init_width, init_height, init_width, init_height);
    }, 400);

    document.addEventListener("keydown", function (event) {
        console.log(event.keyCode);

        let ofset = 16 ;

        if (event.keyCode == 8) {
            text_object.innerHTML = text_object.innerHTML.slice(0, Math.max(command_length, text_object.innerHTML.length - 1));
            ofset = 0 ;
        }
        else {
            if (event.keyCode == 13) {
                past_text.push(text_object);

                text_object = new Objects.TextBox('div', "root@user: ~$ ", 8, past_text[past_text.length - 1].y + cursor.height, 18, 'darkgreen');
            }
            else {
                if (event.keyCode != 16)
                    text_object.innerHTML += event.key;
            }
        }

        cursor.x = text_object.getElementWidth() + ofset;
        cursor.y = text_object.y;

        let print_array = [main_object];

        for (let ind = 0; ind < past_text.length; ind++)
            print_array.push(past_text[ind]);

        print_array.push(text_object);

        cursor.width = (cursor.width == 2) ? 0 : 2;
        print_array.push(cursor);

        main_window.innerHTML = Core.parser_normal(print_array, init_width, init_height, init_width, init_height);
    })

});