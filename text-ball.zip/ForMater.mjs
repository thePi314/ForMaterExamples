/* Modules */
import * as Core from './Core/Module.mjs';

/* Objects */
import * as Objects from './Objects/Modules.mjs' ;

var init_width = 0;
var init_height = 0;
var width = 0;
var height = 0;

var main_window = null ;

var objects_number = 0 ;
var string = ["This is some string!" , "This is yet another string, a bit longer!" , "Now this... This is complite nonsence:\n 'asdadwadawfhseuofheiofhwe8ofhso8fy'" ] ;
var animation_index = 0 ;
var character_amount = 1 ;

let main_object = new Objects.Main('div');

window.onresize = async function () {
    width = window.innerWidth;
    height = window.innerHeight;
    applyStyle(main_object);
}

/* Constructor */
window.addEventListener('load', (event) => {
    init_width = width = window.innerWidth;
    init_height = height = window.innerHeight;

    main_window = document.getElementById('application') ;

    //console.log(Core.parser_normal([main_object],init_width,init_height,init_width,init_height))

    let fall_speed = 0 ;
    let grav = 0.5 
    
    let add_spd = 1 ;
    let spd = 12;

    setInterval(function(){
        main_object.setInnerHTML((string[animation_index]+"                 ").slice(0,character_amount));

        if( character_amount+1 >= (string[animation_index]+"                 ").length ){
            character_amount = 1 ;
            
            if( animation_index+1 >= string.length ){
                animation_index = 0 ;
            }
            else{
                animation_index++ ;
            }
        }
        else{
            character_amount++ ;
        }
        

        // y
        if( main_object.children[0].y + fall_speed <= (init_height-32) ){
            fall_speed += grav ;
        }
        else{
            main_object.children[0].y = (init_height-32) ;
            fall_speed *= -1 ;
        }
        main_object.children[0].y += fall_speed ;

        //x
        if( 32 <= (main_object.children[0].x+add_spd*spd) && (main_object.children[0].x+add_spd*spd) <= (init_width-32) ){
            main_object.children[0].x += add_spd*spd ;
        }
        else{
            add_spd *= -1 ;
        }

        main_window.innerHTML = Core.parser_normal([main_object],init_width,init_height,init_width,init_height);
    },30);
  
});