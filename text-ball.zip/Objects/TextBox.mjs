import * as Core from '../Core/Module.mjs';

export default class TextBox extends Core.Object{
    constructor(type, text = '' ,  x = 0 , y = 0 , size = 16 , color = 'black'){
        super(type) ;

        this.x = x ;
        this.y = y ;
        this.size = size ;
        this.color = color ;

        for( let ind_text = 0 ; ind_text < text.length ; ind_text++ ){
            this.innerHTML += (text[ind_text] != '\n')?text[ind_text]:"</br>" ;
        }

        this.attributes.push( new Core.Attribute( 'color' , this.color ) );
        this.attributes.push( new Core.Attribute( 'font-size' , this.size ) );
    
        this.animation_interval = null ;
    }

}