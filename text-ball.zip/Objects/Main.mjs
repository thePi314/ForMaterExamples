import * as Core from '../Core/Module.mjs';
import Attribute from '../Core/Classes/Attribute.mjs';

export default class Main extends Core.Object {
    constructor(type) {
        super(type);
        this.width = window.innerWidth;
        this.height = window.innerHeight;

        let bcgclr = new Attribute('background-color', 'black');
        let clr = new Attribute('color', 'white');
        let align = new Attribute('text-align','center');

        this.attachAttribute(bcgclr);
        this.attachAttribute(clr);
        this.attachAttribute(align) ;

        let ball_object = new Core.Object('span','ball') ;
        ball_object.x = this.width/2 ;
        ball_object.y = 128 ;
        ball_object.width = 32 ;
        ball_object.height = 32 ;

        let sss = new Attribute( 'border-radius' , '16px' ) ;
        let ss = new Attribute( 'background-color' , 'white' );

        ball_object.attachAttribute(sss);
        ball_object.attachAttribute(ss) ;

        this.attachChildren(ball_object) ;
    }

    setInnerHTML(value) {
        this.innerHTML = value;
    }
}
