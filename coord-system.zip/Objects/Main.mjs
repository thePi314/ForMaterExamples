import * as Core from '../Core/Module.mjs';
import Attribute from '../Core/Classes/Attribute.mjs';

export default class Main extends Core.Object {
    constructor(type) {
        super(type);

        // main object
        this.width = window.innerWidth;
        this.height = window.innerHeight;

        let bcgclr = new Attribute('background-color', 'black');
        this.attachAttribute(bcgclr);

        for (let xx = 32; xx < this.height; xx += 32) {
            let ball_object = new Core.Object('span', 'line');
            
            ball_object.x = 0 ;
            ball_object.y = xx ;
            ball_object.width = this.width;
            ball_object.height = 1;

            let ss = new Attribute('background-color', '#009900');
            ball_object.attachAttribute(ss);
            this.attachChildren(ball_object);
        }

        for (let xx = 32; xx < this.width; xx += 32) {
            let ball_object = new Core.Object('span', 'line');
            
            ball_object.x = xx ;
            ball_object.y = 0 ;
            ball_object.width = 1;
            ball_object.height = this.height;

            let ss = new Attribute('background-color', '#009900');
            ball_object.attachAttribute(ss);
            this.attachChildren(ball_object);
        }
    }

    setInnerHTML(value) {
        this.innerHTML = value;
    }
}
