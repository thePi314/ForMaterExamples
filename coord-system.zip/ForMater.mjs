/* Modules */
import * as Core from './Core/Module.mjs';

/* Objects */
import * as Objects from './Objects/Modules.mjs';
import { irandom_range } from './Core/Calculations/Random.mjs';

var init_width = 0;
var init_height = 0;
var width = 0;
var height = 0;

var main_window = null;

var objects_number = 0;
var string = ["This is some string!", "This is yet another string, a bit longer!", "Now this... This is complite nonsence:\n 'asdadwadawfhseuofheiofhwe8ofhso8fy'"];
var animation_index = 0;
var character_amount = 1;

let main_object = new Objects.Main('div');

//notification
let notify = new Core.Object('div', 'notify');

let attrib1 = new Core.Attribute('background-color', 'white');
let attrib2 = new Core.Attribute('color', 'black');
let attrib3 = new Core.Attribute('opacity', '0.9');
let attrib4 = new Core.Attribute('text-align', 'center');

notify.attachAttribute(attrib1);
notify.attachAttribute(attrib2);
notify.attachAttribute(attrib3);
notify.attachAttribute(attrib4);


//cursor
let cursor = new Core.Object('div','cursor');
let atr1 = new Core.Attribute('background-color' , 'blue');
cursor.attachAttribute(atr1) ;


window.onresize = async function () {
    width = window.innerWidth;
    height = window.innerHeight;
    applyStyle(main_object);
}

/* Constructor */
window.addEventListener('load', (event) => {
    init_width = width = window.innerWidth;
    init_height = height = window.innerHeight;

    notify.width = 256;
    notify.height = 128;
    notify.x = init_width - notify.width - 16;
    notify.y = 16;

    cursor.width = 32 ;
    cursor.height = 32 ;
    cursor.x = irandom_range(0,Math.round( init_width/32 )-1)*32;
    cursor.y = irandom_range(0,Math.round( init_height/32 )-1)*32;

    let cursor_move_interval = null ;

    let move_to_x = -1 ;
    let move_to_y = -1 ;

    main_window = document.getElementById('application');
    main_window.innerHTML = Core.parser_normal([main_object , cursor], init_width, init_height, init_width, init_height);

    document.addEventListener("keydown", function (event) {
        switch (event.keyCode) {
            case 27:
                main_window.innerHTML = Core.parser_normal([main_object,cursor], init_width, init_height, init_width, init_height);
                break ;
        }
    });

    document.addEventListener("click", function (event) {
        notify.innerHTML = "Coords: ( " + (Math.round(event.clientX / 32) * 32) + " , " + (Math.round(event.clientY / 32) * 32) + ")" + "<br>" + "Chunk: ( " + (Math.round(event.clientX / 32)) + " , " + (Math.round(event.clientY / 32)) + ")";

        move_to_x = Math.round(event.clientX / 32) ;
        move_to_y = Math.round(event.clientY / 32) ;

        cursor.x += ( cursor.x/32 > move_to_x )?-32:( ( cursor.x/32 < move_to_x )?32:0 ) ;
        cursor.y += ( cursor.y/32 > move_to_y )?-32:( ( cursor.y/32 < move_to_y )?32:0 ) ;

        main_window.innerHTML = Core.parser_normal([main_object, cursor , notify], init_width, init_height, init_width, init_height);
    });
});